#include "header.h"

int main(int argc, char *argv[]) {
    if(argc != 6) {
        write(2, "usage: ./way_home [file_name] [x1] [y1] [x2] [y2]\n", 51);
        return 0;
    }
    char buf;
    int file = open(argv[1], O_RDONLY);
    
    if(file == -1) {
        write(2, "map doesn't exist\n", 19);
        return 0;
    }
    else {
        if(read(file, &buf, 1) == 0) {
            write(2, "map doesn't exist\n", 19);
            return 0;
        }   
    }
    int width = 0;
    int height = 0;
    int tmpx = 0;
    int tmpy = 0;
    int x1 = mx_atoi(argv[3]);
    int y1 = mx_atoi(argv[2]);
    int x2 = mx_atoi(argv[5]);
    int y2 = mx_atoi(argv[4]);
    
    while(read(file, &buf, 1) > 0) {
        if(buf == '\n') {
            height++;
        }
    }
    close(file);
    file = open(argv[1], O_RDONLY);
    while(read(file, &buf, 1) > 0 && buf != '\n') {
        if(buf != ',') {
            width++;
        }
    }
    close(file);
    file = open(argv[1], O_RDONLY);
    while(read(file, &buf, 1) > 0) {
        if (buf != ',' && buf != '\n') {
            tmpx++; 
        }
        else if(buf == '\n') {
            if(tmpx == width) {
                tmpx = 0;
                tmpy++;
            }
            else {
                write(2, "map error\n", 10);
                return 0;
            }
        }
    }
    close(file);
    int y = 0;
    int x = 0;
    char table[height][width];
    char table1[height][width];
    
    file = open(argv[1], O_RDONLY);
    while(read(file, &buf, 1) > 0) { 
        if (buf != '\n' && buf != ',') {
            table[y][x] = buf;
            table1[y][x] = buf;
            x++;
        }
        else if (buf == '\n') {
            y++;
            x = 0;
        }
    }
    close(file);
    if (table[x1][y1] == '#') {
        write(2, "entry point cannot be an obstacle\n", 34);
        return 0;
    }
    if (table[x2][y2] == '#') {
        write(2, "exit point cannot be an obstacle\n", 33);
        return 0;
    }
    if (table[x1+1][y1] == '#' && table[x1-1][x1] == '#' && table[x1][y1+1] == '#' && table[x1][y1-1] == '#') {
        write(2, "route not found\n", 16);
        return 0;
    }
    if (table[x2+1][y2] == '#' && table[x2-1][y2] == '#' && table[x2][y2+1] == '#' && table[x2][y2-1] == '#') {
        write(2, "route not found\n", 16);
        return 0;
    }
    for (int i = 0; i != height; i++) {
        for (int j = 0; j != width; j++) {
            if (table[i][j] == '.' || table[i][j] == '#' || table[i][j] == '\n') {
                continue;
            }
            else {
                write(2, "map error\n", 10);
                return 0;
            }
        }
    }
    if (x1 > width || y1 > height || x2 > width || y2 > height) {
        write(2, "points are out of map range\n", 28);
        return 0;
    }
    enum TAB tab = UP;
    char distance = 65;
    int count = 0;
    
    for(int i = 0; i < height; i++) {
            for(int j = 0; j < width; j++) {
                if(table[i][j] == '.') {
                    count++;
                }
            }
        }
    table[x1][y1] = distance;
    for(int k = 0; k < count; k++) {
        for(int i = 0; i < height; i++) {
            for(int j = 0; j < width; j++) {
                if(table[i][j] == distance) {
                    if(table[i+1][j] != '#' && table[i+1][j] == '.') {
                        table[i+1][j] = distance + 1;
                    }
                    if(table[i-1][j] != '#' && table[i-1][j] == '.') {
                        table[i-1][j] = distance + 1;
                    }
                    if(table[i][j+1] != '#' && table[i][j+1] == '.') {
                        table[i][j+1] = distance + 1;
                    }
                    if(table[i][j-1] != '#' && table[i][j-1] == '.') {
                        table[i][j-1] = distance + 1;
                    }
                }
            }
        }
        distance += 1;
    }
    distance = 65;
    for(int i = 0; i < height; i++) {
        for(int j = 0; j < width; j++) {
            if(table[i][j] > distance) {
                distance = table[i][j];
            }
        }
    }
    int dist = (int)distance - 65;
    int exit = (int)table[x2][y2] - 65;
    
    if(dist == exit) {
        table1[x2][y2] = 'X';
    }
    else {
        table1[x2][y2] = '*';
    }
    if(exit < 0) {
        write(2, "route not found\n", 16);
        return 0;
    }
    mx_printstr("dist=");
    mx_printint(dist);
    mx_printchar('\n');
    mx_printstr("exit=");
    mx_printint(exit);
    mx_printchar('\n');
    char point = table[x2][y2];
    
    for(int i = x2, j = y2, k = 0; k < exit; k++) {
        switch(tab) {
            case UP:
                if(table[i-1][j] == point) {
                    table[i-1][j] = '*';
                    table1[i-1][j] = '*';
                    i--;
                    tab = UP;
                }
                else if(table[i][j+1] == point) {
                    table[i][j+1] = '*';
                    table1[i][j+1] = '*';
                    j++;
                    tab = RIGHT;
                }
                else if(table[i][j-1] == point) {
                    table[i][j-1] = '*';
                    table1[i][j-1] = '*';
                    j--;
                    tab = LEFT;
                }
                else if(table[i+1][j] == point) {
                    table[i+1][j] = '*';
                    table1[i+1][j] = '*';
                    i++;
                    tab = DOWN;
                }
            break;
            case DOWN:
                if(table[i+1][j] == point) {
                    table[i+1][j] = '*';
                    table1[i+1][j] = '*';
                    i++;
                    tab = UP;
                }
                else if(table[i][j-1] == point) {
                    table[i][j-1] = '*';
                    table1[i][j-1] = '*';
                    j--;
                    tab = RIGHT;
                }
                else if(table[i][j+1] == point) {
                    table[i][j+1] = '*';
                    table1[i][j+1] = '*';
                    j++;
                    tab = LEFT;
                }
                else if(table[i-1][j] == point) {
                    table[i-1][j] = '*';
                    table1[i-1][j] = '*';
                    i--;
                    tab = DOWN;
                }
            break;
            case RIGHT:
                if(table[i][j+1] == point) {
                    table[i][j+1] = '*';
                    table1[i][j+1] = '*';
                    j++;
                    tab = RIGHT;
                }
                else if(table[i+1][j] == point) {
                    table[i+1][j] = '*';
                    table1[i+1][j] = '*';
                    i++;
                    tab = DOWN;
                }
                else if(table[i-1][j] == point) {
                    table[i-1][j] = '*';
                    table1[i-1][j] = '*';
                    i--;
                    tab = UP;
                }
                else if(table[i][j-1] == point) {
                    table[i][j-1] = '*';
                    table1[i][j-1] = '*';
                    j--;
                    tab = RIGHT;
                }
            break;
            case LEFT:
                if(table[i][j-1] == point) {
                    table[i][j-1] = '*';
                    table1[i][j-1] = '*';
                    j--;
                    tab = LEFT;
                }
                else if(table[i-1][j] == point) {
                    table[i-1][j] = '*';
                    table1[i-1][j] = '*';
                    i--;
                    tab = UP;
                }
                else if(table[i+1][j] == point) {
                    table[i+1][j] = '*';
                    table1[i+1][j] = '*';
                    i++;
                    tab = DOWN;
                }
                else if(table[i][j+1] == point) {
                    table[i][j+1] = '*';
                    table1[i][j+1] = '*';
                    j++;
                    tab = RIGHT;
                }
            break;
        }
        point -= 1;
    }
    table1[x1][y1] = '*';
    for(int i = 0; i < height; i++) {
        for(int j = 0; j < width; j++) {
            if(table[i][j] == distance && table1[i][j] != 'X') {
                table1[i][j] = 'D';
            }
        }
    }
    int file_result = open("path.txt", O_WRONLY);
    
    if (file_result < 0) {
        file_result = open("path.txt", O_CREAT | O_EXCL | O_WRONLY, S_IWUSR | S_IRUSR);
    }
    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {
            char buffer = table1[i][j];
            write(file_result, &buffer, 1);
        }
        write(file_result, "\n", 1);
    }
    if(close(file_result) < 0) {
        write(2, "error\n", 6);
    }
    return 0;
}

